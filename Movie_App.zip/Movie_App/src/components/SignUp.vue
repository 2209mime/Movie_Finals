<template>
<h2>Sign Up Page</h2>
<input type="text" placeholder="Enter your name" v-model="fullName" /><br />
<input type="number" placeholder="Enter your age" v-model="age" /><br />
<input type="email" placeholder="Enter your email" v-model="email" /><br />
<input type="password" placeholder="Enter your password" v-model="password" /><br />
<button v-on:click="signUp()">SignUp</button>
<br /><br /><br />
<button v-on:click="backToHomePage()">Back to home page</button>
</template>

<script>
//import axios from "axios";
import bcrypt from "bcryptjs";
export default {
    name: 'signUpComp',
    data() {
        return {
            fullName: '',
            age: '',
            email: '',
            password: ''
        }
    },
    methods: {
        /*
        async signUp() {

            let result = await axios.post("http://localhost:3000/users", {
                name: this.fullName,
                age: this.age,
                email: this.email,
                password: this.password
            });

            if (result.status == 201) {
                localStorage.setItem("user-info", JSON.stringify(result.data));
                this.$router.push({
                    name: 'LandingPage'
                })
            } else {
                alert("sign-up unsucessfull")
            }

        },
        */
        async signUp() {
            const user = {
                name: this.fullName,
                age: this.age,
                email: this.email,
                password: bcrypt.hashSync(this.password,10)
            }
            const users = await fetch(`http://localhost:3000/users/?email=${this.email}`);
            const userName = await users.json();
            if (userName.length === 0) {
                const res = await fetch("http://localhost:3000/users", {
                    method: "POST",
                    headers: {
                        "content-type": "application/json",
                    },
                    body: JSON.stringify(user),
                });
                if (res.status === 201) {
                    {
                        alert("registration succces");
                        this.$router.push({
                            name: 'LoginPage'
                        })
                    }
                } else {
                    alert('registration unsuccess. Please try again!');
                    this.fullName = '',
                        this.age = '',
                        this.email = '',
                        this.password = ''

                }
            } else {
                window.alert("Username already exists. Use different details");
                this.fullName = '',
                    this.age = '',
                    this.email = '',
                    this.password = ''
            }
        },
        backToHomePage() {
            return this.$router.push({
                name: 'HomePage'
            });
        }
    }
}
</script>

<style>

</style>
