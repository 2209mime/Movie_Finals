<template>
<h2>About Us Page: </h2>

<button v-on:click="backToHomePage()">Back to home page</button>
</template>

<script>
export default {
    name: 'aboutUsComp',
    methods:{
        backToHomePage(){
            return this.$router.push({name: 'HomePage'})
        }
    }
}
</script>

<style>
</style>