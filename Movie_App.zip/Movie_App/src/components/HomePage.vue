<template>
<v-img alt="movie logo" src="../assets/movieLogo.jpg"             
              height="50px"
              width="50px"
              cover
/>
<h2>Welcome to Movie App</h2>
<br/>
<div>
    <v-btn v-on:click="guestPage()">Guest</v-btn><br /><br />
    <v-btn v-on:click="loginPage()">Login</v-btn><br /><br />
    <v-btn v-on:click="signUpPage()">SignUp</v-btn><br /><br />
</div>

<div class="footer">
    <button v-on:click="aboutUsPage()">About Us</button>
</div>
</template>

<script>
export default {
    name: 'homePageComp',
    methods: {
        signUpPage() {
            return this.$router.push({
                name: 'SignUpPage'
            })
        },
        loginPage() {
            return this.$router.push({
                name: 'LoginPage'
            })
        },
        guestPage() {
            return this.$router.push({
                name: 'LandingPage'
            })
        },
        aboutUsPage() {
            return this.$router.push({
                name: 'AboutUsPage'
            })
        }
    }
}
</script>

<style>
img {
    width: 200px;
}

.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: green;
    color: white;
    text-align: center;
}
</style>
