<template>
    <H2>My Favorite Movies</H2>
    <input type="text" id="email" v-model="email"/>
    <table border="1" class="favTable">
      <thead>
        <tr>
          <td>Poster</td>
          <td>Title</td>
          <td>Rating</td>
          <td>Delete</td>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in favorites" :key=item.movieName>
          <td><img id="imgPoster" :src="item.moviePoster" class="img-thumbnail" /></td>
          <td>{{item.movieName}}</td>
          <td>{{item.movieRating}}</td>
        </tr>
      </tbody>
    </table>
  </template>
  <style>
  favTable{
    text-align: center;
  }
  td{
    width: 150px;
  }
  </style>
  <script>
  import axios from 'axios'
  export default{
    name:'FavoritesComp',
    data()
      {
        return{
          email:'preethi@gmail.com',
          favorites:[]
        }
      },
      async mounted(){
        let result = await axios.get('http://localhost:3000/favorites/?email='+this.email+'');
        this.favorites = result.data;
      }
  }
  </script>