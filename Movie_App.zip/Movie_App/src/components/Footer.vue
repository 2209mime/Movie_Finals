<template>
    <div class="footer">
        <span class="footer_text">© all right reserved by movie app 2022.</span>
    </div>
  </template>

  <script>
  export default {
    name: 'FooterComp',
  }
  </script>

  <style scoped>
  .footer{
    background-color: #1c3d63 !important;
    color: #fff;
    text-align: center;
    padding: 6px;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

  }
  </style>