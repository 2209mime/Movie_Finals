<template>
<header class="header">
    <span class="header_logo">Movies App</span>

    <div class="header_right">
        <span class="header_menu">Home</span>
        <span class="header_menu">Favourites</span>
        <span class="header_menu1">Profile <span class="avatar">P</span></span>
    </div>
</header>
</template>

  
<script>
export default {
    name: 'HeaderComp',

}
</script>

<style>
.header {
    background-color: #1c3d63;
    display: flex;
    padding: 10px 10px;
    justify-content: space-between;
    color: #fff;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.header_menu {
    border-right: 2px solid white;
    padding-right: 10px;
    margin-left: 10px;
    cursor: pointer;
    opacity: 0.6;

}

.header_menu1 {
    margin-left: 10px;
    cursor: pointer;
    opacity: 0.6;
}

.header_menu:hover {
    opacity: 1;
}

.header_menu1:hover {
    opacity: 1;
}

.avatar {
    padding: 3px 7px;
    font-size: 13px;
    font-weight: bolder;
    color: #000;
    background: #fff;
    border-radius: 50px;
}
</style>
