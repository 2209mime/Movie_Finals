<template>
    <div>
      <h2>Comparision Page</h2>
      <table id="datatable">
        <thead>
          <tr>
            <th>Movie Names</th>
            <th>Ratings</th>
            <th>Box Office</th>
            <th>Run Time</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.Title">
            <td>{{ user.Title }}</td>
            <td>{{ user.Rated }}</td>
            <td>{{ user.BoxOffice }}</td>
            <td>{{ user.Runtime }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
   
  <script>
//   import "jquery/dist/jquery.min.js";
//   import "bootstrap/dist/css/bootstrap.min.css";
//   import "datatables.net-dt/js/dataTables.dataTables";
//   import "datatables.net-dt/css/jquery.dataTables.min.css";
//   import $ from "jquery";
  
  
  export default {
    name:'comparisonPageComp',
//     mounted() {
//       let routeParam = window.location.href.split('/').slice(-1)[0];
//       console.log("url", "http://www.omdbapi.com/?apikey=eba5c9e9&t="+routeParam);
//       fetch("http://www.omdbapi.com/?apikey=eba5c9e9&t="+routeParam)
//         .then((response) => response.json())
//         .then((data) => {
  
  
//           this.users.push(data);
//           this.users.push({
//         "Title": "The Baby Boss",
//         "Rated": "PG-13",
//         "BoxOffice": "$623,321,649",
//         "Runtime": "152 min"
//       });
//       this.users.push({
//         "Title": "Peppa Pig",
//         "Rated": "PG-13",
//         "BoxOffice": "$789,321,543",
//         "Runtime": "158 min"
//       });
//         //   setTimeout(() => {
//         //     $("#datatable").DataTable({
//         //       columnDefs: [{
//         //               targets: [0, 1,2, 3],
//         //               className: 'dt-left'
//         //           }]
//         //     });
//         //   });
//         // });
//     },
//     data: function () {
//       return {
//         users: [],
//       };
//     },
// //   };
  }
  </script>
  
  <style>
  table.dataTable.no-footer {
      border: 1px solid rgba(0, 0, 0, 0.3);
  }
  .dataTables_wrapper {  
      margin: 50px;
  }
  .dataTables_filter{
      margin-bottom: 10px;
  }
  </style>