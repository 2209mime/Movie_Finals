<template>
<header>
    <h1>Movie <span>App</span></h1>
</header>
<div class="landing">
    <div class="featuredMovie">
        <router-link to="/movie/tt0499549">
            <img src="https://www.critic.de/images/avatar-65139.jpg" alt="Avatar Poster" class="moviePoster" />
        </router-link>
            <div class="detail">
                <h3>Avatar</h3>
                <p>A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home. It is set in the mid-22nd century when humans are colonizing Pandora, a lush habitable moon of a gas giant in the Alpha Centauri star system, in order to mine the valuable mineral unobtanium. The expansion of the mining colony threatens the continued existence of a local tribe of Na'vi: a humanoid species indigenous to Pandora. The title of the film refers to a genetically engineered Na'vi body operated from the brain of a remotely located human that is used to interact with the natives of Pandora</p>
            </div>
    </div>
    <div class="searchBar">

        <input type="text" placeholder="Search for a movie.." name="search2">
        <button type="submit">submit</button>

    </div>
</div>
<router-link to="/detailPage">DetailsPage</router-link>
</template>

<script>
export default {
    name: 'langingPageComp'
}
</script>

<style>
body {
    font-family: Arial;
}

header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 5px 5px;
    background-color: greenyellow;
    box-shadow: 0px 0px 6px 6px;
}

.featuredMovie {
    position: relative;
}

.moviePoster {
    display: block;
    width: 20%;
    height: 300px;
    object-fit: cover;
    position: relative;

}

.detail {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.0);
    padding: 16px;
}

p {
    color: black;
    position: relative;
    right: 0;
}

div.searchBar input{
    padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}
</style>
