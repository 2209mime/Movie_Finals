<template>
<HeaderComponent />

<div class="container">

    <span class="movie_title">{{data?.Title}}</span>

    <span class="wishlist movie_data_subheading">

        Add to Favourite 
        <!-- <button v-on:click="favPage()"><img style="width: 30px;" src="../assets/favoriteIcon.jpg" alt="fav icon"></button> -->
        <v-btn v-on:click="favPage()" size="large" color="red" variant="text" icon="mdi-heart"></v-btn>
    </span>

    <div class="section">
        <img class="movie_img" src="https://m.media-amazon.com/images/M/MV5BNjA3NGExZDktNDlhZC00NjYyLTgwNmUtZWUzMDYwMTZjZWUyXkEyXkFqcGdeQXVyMTU1MDM3NDk0._V1_SX300.jpg" alt="movie_poster" />
        <div class="side_section">
            <span class="movie_data_subheading"><b>Duration</b> : {{data?.Runtime}}</span>
            <span class="movie_data_subheading"><b>Ratings</b> : {{data?.imdbRating}}</span>
            <span class="movie_data_subheading"><b>Released Date</b> : {{data?.Released}}</span>
            <span class="movie_data_subheading"><b>Genre</b> : {{data?.Genre}}</span>
            <span class="movie_data_subheading"><b>Language</b> : {{data?.Language}}</span>

            <div class="btn_list">
                <button class="btn">Watch Trailer</button>
                <button class="btn btn_1">Watch Movie</button>
            </div>
        </div>

    </div>

    <p class="movie_data_subheading add_margin"><b>Description :</b></p>
    <span class="movie_data_subheading">{{data?.Plot}}</span>

    <p class="movie_data_subheading"><b>Cast and Crew</b></p>
    <p class="movie_data_subheading"><b>Director : </b> {{data?.Director}}</p>
    <p class="movie_data_subheading"><b>Writer : </b> {{data?.Writer}}</p>
    <p class="movie_data_subheading"><b>Actors : </b> {{data?.Actors}}</p>

    <div class="spacer">
        <button class="btn" v-on:click="setDialog(data?.Title)">Submit rating</button>
        <p v-if="data?.movieRating" class="movie_data_subheading"><b>Submitted Rating : </b> {{data?.movieRating}} /10 </p>
        <v-dialog
      v-model="dialog" 
    >

      <v-card>
        <v-container>
      <RatingComp :title="this.title" @rated="onSelectRating"/>  
        </v-container>
        <v-card-actions>
            <v-spacer/>
            <!-- <v-col :align-self="'center'"> -->
          <v-btn color="primary"  @click="dialog = false">Close</v-btn>
          <v-btn color="primary"  @click="onSubmit(movieRating)">Submit</v-btn>
        <!-- </v-col> -->
        </v-card-actions>
        
      </v-card>
    </v-dialog>
        <!--<button class="btn btn_1">Clich here for more info</button>-->
    </div>

    <div>
        <button v-on:click="comparisonPage()">Compare Info</button>
    </div>
</div>
<FooterComponent />
</template>

<script>
import HeaderComponent from './Header.vue'
import FooterComponent from './Footer.vue'
import axios from 'axios'
import RatingComp from './Rating.vue'

export default {
    name: 'DetailPageComp',
    data() {
        return {
            data: null,
            title:'',
              dialog: false, 
              movieRating: {},
        }
    },
    components: {
        HeaderComponent,
        FooterComponent,
        RatingComp
    },


    mounted() {
        axios
            .get('http://www.omdbapi.com/?t=avatar&apikey=d3ed7a5c')
            .then(response => this.data = response.data)
    },
    methods: {
        comparisonPage() {
            return this.$router.push({
                name: 'comparisonPage'
            })
        },
        favPage() {
            return this.$router.push({
                name: 'FavoritesPage'
            })
        },
        submitReview() {
            return this.$router.push({
                name: 'RatingsPage'
            })
        },
        setDialog(val){
                this.dialog=true;
                this.title=val;
            }, 
            onSelectRating(val){
                this.data.movieRating=val;
            //   console.log(val,"This is main page")
            },
            onSubmit(){
                
                // this.movieRating=val?.rating;
            //   console.log(val);
              this.dialog=false;
            },
    }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
.container {
    margin: 40px 20px;
}

.movie_title {
    font-size: 30px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.movie_img {
    max-height: 30% !important;
    height: 260px;
    object-fit: cover;
    width: 200px;
}

p {
    margin-bottom: 0px !important;
}

.section {
    margin-top: 20px;
    display: flex;
}

.side_section {
    margin-left: 20px;
    margin-bottom: 10px !important;
    display: flex;
    flex-direction: column;
}

.add_margin {
    margin-bottom: 10px !important;
}

.movie_data_subheading {
    margin-bottom: 5px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

}

.btn {
    padding: 6px;
    background-color: #76b1fe;
    border: none;
    border-radius: 4px;
    border: 2px solid #76b1fe;
    margin-right: 10px;
    margin-top: 20px;
    cursor: pointer;
}

.btn:hover {
    background-color: #318afe;

}

.btn_1:hover {
    background-color: #318afe !important;

}

.btn_1 {
    background-color: #fff !important;
    cursor: pointer;
}

.btn_list {
    display: flex;
    cursor: pointer;

}

.spacer {
    display: flex;
    justify-content: space-between;
}

.wishlist {
    position: absolute;
    min-width: 30px;
    min-height: 30px;
    position: absolute;
    right: 20px;
}
</style>
