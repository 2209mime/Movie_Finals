<template>
<h2>LoginPage</h2>
<input type="email" placeholder="Enter your email" v-model="email" /><br />
<input type="password" placeholder="Enter your password" v-model="password" /><br />
<button v-on:click="login()">Login</button>
<br /><br /><br />
<button v-on:click="backToHomePage()">Back to home page</button>
</template>

<script>
import bcrypt from 'bcryptjs';
export default {
    name: 'loginPageComp',
    data() {
        return {
            email: '',
            password: ''
        }
    },
    methods: {
        async login() {
            const existingUser = await fetch(`http://localhost:3000/users/?email=${this.email}`);
            const existingUserData = await existingUser.json();
            if (existingUserData.length > 0) {
                let doesPasswordMatch = bcrypt.compareSync(this.password, existingUserData[0].password);
                if (doesPasswordMatch) {
                    return this.$router.push({
                        name: 'LandingPage'
                    })
                } else {
                    alert('Incorrect password! retry');
                    this.password = '';
                }
            } else {
                alert("User not found");
                this.email = '';
                this.password = '';
            }
        },
        backToHomePage() {
            return this.$router.push({
                name: 'HomePage'
            })
        }
    }
}
</script>

<style>

</style>
