import { createRouter, createWebHistory } from 'vue-router'
import homePageComp from './components/HomePage.vue'
import signUpComp from './components/SignUp.vue'
import langingPageComp from './components/LandingPage.vue'
import loginPageComp from './components/LoginPage.vue'
import aboutUsComp from './components/AboutUs.vue'
import DetailPageComp from './components/DetailPage.vue'
import HeaderComp from './components/Header.vue'
import FooterComp from './components/Footer.vue'
import RatingPageComp from './components/Rating.vue';
import comparisonPageComp from './components/ComparisonPage.vue'
import FavoritesComp from './components/Favorites.vue'

const routes = [
    {
        name: 'HomePage',
        path: '/',
        component: homePageComp
    },
    {
        name: 'SignUpPage',
        path: '/signUp',
        component: signUpComp
    },
    {
        name: 'LoginPage',
        path: '/login',
        component: loginPageComp
    },
    {
        name: 'LandingPage',
        path: '/landingPage',
        component: langingPageComp
    },
    {
        name: 'AboutUsPage',
        path: '/aboutUs',
        component: aboutUsComp
    },
    {
        name: 'DetailPage',
        path: '/detailPage',
        component: DetailPageComp
    },
    {
        name: 'Header',
        path: '/header',
        component: HeaderComp
    },
    {
        name: 'Footer',
        path: '/footer',
        component: FooterComp
    },
    {
        name: 'RatingsPage',
        path: '/rating',
        component: RatingPageComp
    },
    {
        name:'comparisonPage',
        path: '/comparisonPage',
        component: comparisonPageComp
    },
    {
        name:'FavoritesPage',
        path:'/favoritesPage',
        component: FavoritesComp
    }
];

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router;